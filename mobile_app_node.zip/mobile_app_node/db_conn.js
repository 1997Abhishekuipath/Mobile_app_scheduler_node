
var express = require('express');

var sql = require('mssql');

var http = require('http');


var config = {
  user: "chatbot",
  password: "Axsw@#$4321",
  server: "gsd-db",
  database: "ksubscribers",
};

// "NAME": "ksubscribers",
// "USER": "chatbot",
// "PASSWORD": "Axsw@#$4321",
// "HOST": "gsd-db",
// "PORT": "1433",


const db_connection = () => {
    // console.log(config)
  sql.connect(config, function (err) {
    
    if (err) return(err);

    return new sql.Request();
    // request.query("SELECT t.id,t.TicketNumber,t.ServiceDesk, t.Status, t.Description, t.Stage, t.Category, t.Created, t.Severity, t.Summary,t.SubmitterName, t.SubmitterEmail, t.Organization, t.Modified, t.Due, c.String1 as engineername FROM ksd.CustomFieldsValues c inner join kasadmin.vSDTicket t on c.Id=t.id where (t.Status != 'Closed' AND t.Status != 'Resolved') and datediff(HH,cast(t.Modified as datetime),cast(GETDATE() as datetime))<=24",function (err, recordset) {

    //     if (err) {return err}
    //     console.log('Inside db_conn function.')
    //     // send records as a response
    //     // res.send(recordset);
    //     console.log(recordset)

    // });
    // return request;
  });
}

exports.db_connection=db_connection