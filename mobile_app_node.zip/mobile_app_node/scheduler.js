const schedule = require('node-schedule');
const {insertTicket,insert_updated_Ticket} = require('./index.js')


const cron1 = '*/5 * * * * *';
const job1 = schedule.scheduleJob(cron1, function () {
    insertTicket()
 });


const cron2 = '*/10 * * * * *';
const job2 = schedule.scheduleJob(cron1, function () {
    insert_updated_Ticket()
 });