const express = require('express')
var sql = require('mssql');
const axios = require('axios')
const app = express()
const port = 3000

var config = {
    user: "chatbot",
    password: "Axsw@#$4321",
    server: "gsd-db",
    database: "ksubscribers",
  };



const insertTicket = () => {

    sql.connect(config, function (err) {
    
        if (err) console.log('error',err);
        var request= new sql.Request();
        request.query( "SELECT t.id,t.TicketNumber,t.ServiceDesk, t.Status, t.Description, t.Stage, t.Category, t.Created, t.Severity, t.Summary,t.SubmitterName, t.SubmitterEmail, t.Organization, t.Modified, t.Due, c.String1 as engineername FROM ksd.CustomFieldsValues c inner join kasadmin.vSDTicket t on c.Id=t.id where (t.Status != 'Closed' AND t.Status != 'Resolved') and datediff(HH,cast(t.Modified as datetime),cast(GETDATE() as datetime))<=24;", function (err, data) {
            console.log('requestss',request)
            if (err) console.log("err",err)
            console.log('Insert Ticket...',data)
        if(data){
            var headers = { "Content-type": "application/json" }
            Api_gateway_payload_obj=[]
            var userData ={"data": Api_gateway_payload_obj,"action":"insert_ticket"} 
              axios.post("https://8aj3hddov3.execute-api.ap-south-1.amazonaws.com/Production/scheduler/", userData,headers).then((response) => {
                console.log(response.status, response.data);
              });
            }
        else{
            console.log('No Data Found..')
        }    
        });
      });


    
}

const insert_updated_Ticket = () => {
    sql.connect(config, function (err) {
    
        if (err) console.log('error',err);
        var request= new sql.Request();
        request.query("SELECT t.id,t.TicketNumber,t.ServiceDesk, t.Status, t.Description, t.Stage, t.Category, t.Created, t.Severity, t.Summary,t.SubmitterName, t.SubmitterEmail, t.Organization, t.Modified, t.Due, c.String1 as engineername FROM ksd.CustomFieldsValues c inner join kasadmin.vSDTicket t on c.Id=t.id where (t.Status != 'Closed') and datediff(HH,cast(t.Modified as datetime),cast(GETDATE() as datetime))<=1", function (err, data) {
            console.log('requestss',request)
            if (err) console.log("err",err)
            console.log('Insert Updated Ticket...',data)
        if(data){
            var headers = { "Content-type": "application/json" }
            var Api_gateway_payload_obj =[]
            var userData = {"data": Api_gateway_payload_obj,"action":"update_ticket"}
              axios.post("https://8aj3hddov3.execute-api.ap-south-1.amazonaws.com/Production/update_ticket_scheduler/", userData,headers).then((response) => {
                console.log(response.status, response.data);
              });
            }
        else{
            console.log('No Data Found..')
        }    
        });
      });
}

exports.insertTicket=insertTicket
exports.insert_updated_Ticket=insert_updated_Ticket